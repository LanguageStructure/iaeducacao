import urllib.request
from pathlib import Path
url='https://raw.githubusercontent.com/LanguageStructure/iaeducacao/f7f0119671111608d425f4c2da1b746ad25a1401/encontro-3/index.html'
s=urllib.request.urlopen(url).read().decode('utf-8')
s=s.replace('<a href="#papagaios">Papagaios</a>\n          <a href="#atividade">Atividade</a>','<a href="#papagaios">Papagaios</a>\n          <a href="#hinton">Pensamento &amp; consciência</a>\n          <a href="#atividade">Atividade</a>')
s=s.replace('<a href="#papagaios">Papagaios estocásticos</a>\n            <a href="#conceitos">Conceitos-chave</a>','<a href="#papagaios">Papagaios estocásticos</a>\n            <a href="#hinton">Hinton: pensamento e consciência</a>\n            <a href="#conceitos">Conceitos-chave</a>')
section='''          <section id="hinton" class="content-section">
            <p class="section-kicker">Geoffrey Hinton · StarTalk</p>
            <h2>Redes neurais, pensamento e consciência</h2>
            <p>Depois de examinar como modelos de linguagem aprendem e geram sequências, podemos formular uma questão mais difícil: <strong>quando um sistema exibe raciocínio linguístico complexo, devemos dizer que ele pensa?</strong> Geoffrey Hinton defende uma resposta afirmativa e leva a discussão até a consciência e a experiência subjetiva.</p>
            <div class="thread-list">
              <section class="thread-item"><span>01</span><div><h3>O que significa pensar? · 34:59–38:30</h3><p>Hinton observa que o pensamento humano envolve diferentes representações — imagens, movimentos e linguagem. Ele sustenta que os grandes modelos de linguagem já podem ser descritos como sistemas que pensam. A afirmação deve ser discutida como uma posição teórica, e não como consenso.</p><p><strong>Questão:</strong> produzir raciocínio linguisticamente articulado é evidência de pensamento, ou apenas de comportamento linguístico complexo?</p></div></section>
              <section class="thread-item"><span>02</span><div><h3>Cérebro × rede neural · 38:30–41:22</h3><p>Hinton compara aproximadamente <strong>100 trilhões (10¹⁴) de conexões</strong> no cérebro humano com cerca de <strong>1 trilhão (10¹²) de conexões/parâmetros</strong> em um LLM grande. Seu ponto principal é o contraste: o cérebro teria muitíssimas conexões e relativamente pouca experiência, enquanto modelos artificiais dispõem de menos conexões, mas são expostos a quantidades enormes de dados.</p><p><strong>Cuidado:</strong> sinapses biológicas e parâmetros de uma rede artificial não são unidades equivalentes. A comparação é de ordem de grandeza; não significa que um LLM seja “1% de um cérebro”.</p></div></section>
              <section class="thread-item"><span>03</span><div><h3>Uma IA pode ser consciente? · 1:23:36–1:28:53</h3><p>Hinton rejeita a imagem da consciência como uma essência misteriosa que surge automaticamente quando um sistema se torna suficientemente complexo. Em uma perspectiva próxima à de Daniel Dennett, propõe pensar em termos de experiência subjetiva e <em>awareness</em>.</p><p>Seu experimento mental usa um chatbot multimodal com câmera e braço robótico. Um prisma altera sua percepção da posição de um objeto. Depois de descobrir a causa do erro, o sistema poderia relatar que o objeto lhe parecia estar em outro lugar. Para Hinton, isso torna menos simples negar de antemão qualquer experiência subjetiva à máquina.</p></div></section>
            </div>
            <div class="implication-box"><p class="thesis-label">Três teses diferentes</p><h3>Raciocinar, pensar e ser consciente não são a mesma afirmação.</h3><p>É preciso distinguir: (1) o sistema exibe comportamentos de raciocínio; (2) o sistema pensa; (3) o sistema possui consciência ou experiência subjetiva.</p></div>
            <div class="article-actions"><a class="text-link" href="https://www.youtube.com/watch?v=l6ZcFa8pybE" rel="noreferrer">Assistir à entrevista no YouTube <span>↗</span></a><a class="text-link" href="hinton.md">Abrir notas de apoio em Markdown <span>→</span></a></div>
          </section>

'''
s=s.replace('          <section id="conceitos" class="content-section">',section+'          <section id="conceitos" class="content-section">')
Path('encontro-3/index.html').write_text(s,encoding='utf-8')
